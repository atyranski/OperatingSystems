#ifndef PRINT_UTILS_H
#define PRINT_UTILS_H

void error(char* type, char* message);

void printInfo(char* type, char* message);

void printCheck(char* message);

#endif